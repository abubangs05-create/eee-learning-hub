/* EEE Learning Hub site configuration
 * Add your real NardoPay checkout/payment URL below before publishing.
 * Example format: 'https://your-real-nardopay-checkout-link'
 * Do not add card details, API secrets or private credentials here.
 */
window.EEE_CONFIG = {
  NARDOPAY_URL: 'https://nardopay.com/d/supporteeelearninghub'
};
