/* EEE Learning Hub member authentication settings. */
window.EEE_AUTH_CONFIG = {
  SUPABASE_URL: 'https://byzhokazayloufsucfmu.supabase.co',
  SUPABASE_ANON_KEY: 'sb_publishable_BkbMVwcdg6cPDhvkeBexPg_3rUDaKS0'
};