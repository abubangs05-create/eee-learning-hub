(() => {
  const cfg = window.EEE_AUTH_CONFIG || {};
  const configured = cfg.SUPABASE_URL && cfg.SUPABASE_ANON_KEY &&
    !cfg.SUPABASE_URL.includes('PASTE_') && !cfg.SUPABASE_ANON_KEY.includes('PASTE_');
  let client;
  const $ = (id) => document.getElementById(id);
  const message = (txt, good=false) => { const el=$('authMessage'); if(el){el.textContent=txt;el.className='notice '+(good?'success':'error');} };
  const show = (id, yes) => { const el=$(id); if(el) el.hidden=!yes; };
  async function start(){
    if (!window.supabase || !window.supabase.createClient) return;
    if (configured) client=window.supabase.createClient(cfg.SUPABASE_URL,cfg.SUPABASE_ANON_KEY);
    const loginLink=document.querySelectorAll('a[href="login.html"]');
    if(!client){ if($('authSetupWarning')) show('authSetupWarning',true); return; }
    const {data:{session}}=await client.auth.getSession(); updateNav(session);
    client.auth.onAuthStateChange((_event,s)=>{updateNav(s); if($('memberEmail')) renderMember(s);});
    if($('loginForm')) bindForms();
    if($('memberEmail')) renderMember(session);
  }
  function updateNav(session){document.querySelectorAll('a[href="login.html"]').forEach(a=>{a.textContent=session?'My Account':'Member Login'; if(session)a.href='member.html';});}
  function bindForms(){
    $('loginForm')?.addEventListener('submit',async e=>{e.preventDefault();message('Signing in…');const email=$('loginEmail').value.trim(),password=$('loginPassword').value;const {error}=await client.auth.signInWithPassword({email,password});message(error?error.message:'Signed in successfully. Opening your member area…',!error);if(!error)setTimeout(()=>location.href='member.html',500);});
    $('signupForm')?.addEventListener('submit',async e=>{e.preventDefault();message('Creating your account…');const name=$('signupName').value.trim(),email=$('signupEmail').value.trim(),password=$('signupPassword').value;if(password.length<8){message('Please use a password with at least 8 characters.');return;}const {data,error}=await client.auth.signUp({email,password,options:{data:{full_name:name}}});if(error){message(error.message);return;}message(data.session?'Account created! Opening your member area.':'Account created. Check your email for the confirmation link, then sign in.',true);if(data.session)setTimeout(()=>location.href='member.html',700);});
    $('showSignup')?.addEventListener('click',()=>{show('loginPanel',false);show('signupPanel',true);message('');});
    $('showLogin')?.addEventListener('click',()=>{show('signupPanel',false);show('loginPanel',true);message('');});
    $('resetPassword')?.addEventListener('click',async()=>{const email=$('loginEmail').value.trim();if(!email){message('Enter your email address first, then choose Forgot password.');return;}const {error}=await client.auth.resetPasswordForEmail(email,{redirectTo:location.origin+location.pathname});message(error?error.message:'Password reset email sent. Check your inbox.',!error);});
  }
  async function renderMember(session){
    if(!session){$('memberEmail').textContent='You are not signed in.';show('memberSignedIn',false);show('memberSignedOut',true);return;}
    show('memberSignedIn',true);show('memberSignedOut',false);
    $('memberEmail').textContent=session.user.email;
    $('memberName').textContent=session.user.user_metadata?.full_name || 'EEE Learning Hub Member';
    $('memberSince').textContent=new Date(session.user.created_at).toLocaleDateString();
    $('logoutButton')?.addEventListener('click',async()=>{await client.auth.signOut();location.href='index.html';},{once:true});
  }
  document.addEventListener('DOMContentLoaded',start);
})();
