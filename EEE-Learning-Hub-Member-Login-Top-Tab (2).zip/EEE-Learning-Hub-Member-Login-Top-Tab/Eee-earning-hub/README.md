# EEE Learning Hub
**Learn • Build • Innovate**

A responsive, static engineering education platform built with HTML5, CSS3 and vanilla JavaScript. It has no paid backend requirement and can be hosted on Netlify, Vercel, GitHub Pages or Cloudflare Pages.

## What is included
- 14 navigable pages plus a custom 404 page.
- Four subject pathways with 50+ structured lessons, worked examples, formulas and knowledge checks.
- 19 working calculators with input validation, formula display and reset controls.
- Searchable notes library, subject filters, note reading and browser-based bookmarks.
- Randomized quizzes with difficulty and subject filters, timer, instant feedback, explanations, results and history.
- Student dashboard with lesson completion, saved notes, quiz performance, recent activity and learning goals.
- Curated learning resources and official engineering software links.
- Responsive navigation, global search, dark mode, print styles, SEO metadata and local assets.
- Browser-local progress; no account or backend is required.

## 1. Extract and run locally
1. Extract `eee-learning-hub.zip`.
2. Open the extracted `eee-learning-hub` folder.
3. Recommended: run a local static server from that folder:
   - Python: `python -m http.server 8000`
   - Then visit `http://localhost:8000`
4. You may open `index.html` directly, but some browsers restrict `fetch()` of JSON data from `file://`. Use the local server for full functionality.

No build step, package installation or paid service is required.

## 2. Add your NardoPay payment link
Open **`js/config.js`**. Replace the empty `NARDOPAY_URL` value with your real HTTPS NardoPay payment URL:
```js
window.EEE_CONFIG = {
  NARDOPAY_URL: 'https://PASTE-YOUR-REAL-NARDOPAY-LINK-HERE'
};
```
Save the file and test the Support Us button. No payment details have been invented and no fake payment processing is included. Do not put private API keys or card details in a public static website.

## 3. Deploy

### Netlify
1. Sign in to Netlify.
2. Choose **Add new site → Deploy manually** (or connect a Git repository).
3. Drag the extracted project folder into the deploy area, or connect the repository.
4. The included `netlify.toml` sets the publish directory to the project root.
5. Add your custom domain in Site settings if desired.

### Vercel
1. Sign in to Vercel and choose **Add New → Project**.
2. Import the Git repository containing this folder, or use Vercel CLI.
3. Select **Other** as the framework preset; no build command is required and the output directory is `.`.
4. Deploy. The included `vercel.json` provides basic headers.

### GitHub Pages
1. Create a GitHub repository and upload the contents of this project folder (not the ZIP itself).
2. Open repository **Settings → Pages**.
3. Choose **Deploy from a branch**, select your branch and `/ (root)`, then save.
4. Wait for the Pages URL to become available. `.nojekyll` is included.
5. If publishing under a repository subpath, keep all assets and data paths relative as supplied.

### Cloudflare Pages
1. Sign in to Cloudflare and choose **Workers & Pages → Create → Pages**.
2. Connect your Git repository.
3. Choose **None** / static HTML as the framework preset; leave build command empty and set build output directory to `/`.
4. Deploy. `_headers` is included for basic response headers.

## 4. Update lessons
Edit `data/subjects.json` for subject overview metadata and `data/lessons.json` for lesson content. Each lesson record contains:
- `id`, `subject`, `subjectTitle`, `title`
- `explanation`, `formula`, `example`, `application`
- `keyPoints` and a `check` object with question, options, answer index and explanation.

Keep IDs unique and use the subject key `electrical`, `electronics`, `mathematics` or `power`. Subject page lesson lists are generated from the corresponding subject data; when adding a new lesson, add its topic to `data/subjects.json` and a matching full record to `data/lessons.json`.

## 5. Add notes
Add a record to `data/notes.json` with a unique `id`, `subject`, `title`, `summary`, `body` (array of paragraphs), and `tags`. Supported subject keys are electrical, electronics, mathematics and power. The Notes Library reads this data automatically.

## 6. Add quizzes
Add a question record to `data/questions.json` with a unique `id`, `subject`, `topic`, `difficulty` (`beginner`, `intermediate`, `advanced`), `q`, `options` (array), `answer` (zero-based correct option index) and `explanation`. The quiz interface randomizes matching questions automatically.

## 7. Update images and branding
Replace SVG files in `assets/img/` with optimized SVG, WebP or PNG images, keeping filenames unchanged or updating their references in HTML. Prefer compressed, appropriately sized images and descriptive alt text. Brand colours and layout tokens are in `css/styles.css` under `:root`.

## 8. Maintain the website
- Test the site using a local server after editing JSON or JavaScript.
- Keep `data/*.json` valid JSON (double quotes, no trailing commas).
- Check external links periodically; third-party services may change their URLs or terms.
- Update `sitemap.xml` and `robots.txt` with your real production domain.
- Update the sample contact email in `contact.html` before publishing.
- Browser progress is stored in local storage on each visitor's device. It does not sync between devices and may be cleared by browser settings.
- Make backups before large content updates.

## Educational and safety notice
This platform is for education and study support. Calculator outputs and example values are not a substitute for applicable electrical codes, equipment datasheets, risk assessments, qualified supervision or professional engineering review. Electrical installation and live-system work must be undertaken only by competent persons using approved safe systems of work.

## Browser support
Designed for current evergreen desktop and mobile browsers. Uses native HTML, CSS and JavaScript; no framework runtime is required.

## Member login setup (Supabase)

The project now includes `login.html` (sign in/create account), `member.html` (member area), and the Member Login navigation link.

1. Create a free project at https://supabase.com/ and open **Project Settings → API**.
2. Copy the **Project URL** and the **anon/public** (or publishable) key. Never use the `service_role` or secret key in frontend code.
3. Open `js/auth-config.js` and replace the two placeholder values with your Project URL and anon/publishable key. Keep the quotation marks.
4. In Supabase, open **Authentication → URL Configuration**. Add your deployed website URL to **Site URL** and **Redirect URLs**. During local testing, add your local development URL too.
5. Deploy the updated website. Visit `login.html` to create a free account or sign in.

Email confirmation may be enabled by default. If it is enabled, a new member must click the confirmation link sent by Supabase before signing in. Configure your email provider and redirect URLs in Supabase before launch.

This first version provides real Supabase authentication and a basic member account page. Existing learning progress remains browser-local; syncing lesson progress and quiz history across devices is a separate next step. The Student Dashboard is not yet a protected premium-content area.
